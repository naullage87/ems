<footer class="page-footer gradient-bg">
    <div class="footer-copyright">
        <div class="container">
            © Copyright
        </div>
    </div>
</footer>