<ul id="slide-out" class="sidenav sidenav-fixed grey lighten-4">
    <li>
        <a href="/admins" class="waves-effect waves-grey"><i class="material-icons">account_circle</i>Admin Management</a>
    </li>
</ul>
